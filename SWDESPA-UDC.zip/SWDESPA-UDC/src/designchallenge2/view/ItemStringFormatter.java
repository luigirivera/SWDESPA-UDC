package designchallenge2.view;

import designchallenge2.item.CalendarItem;

public interface ItemStringFormatter {
	public String format(CalendarItem item);
}
