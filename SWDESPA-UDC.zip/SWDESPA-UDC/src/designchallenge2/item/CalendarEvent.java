package designchallenge2.item;


public class CalendarEvent extends CalendarItem {
	public static final String DEFAULT_COLOR = "#3333EE";
}
