package ultimatedesignchallenge.controller;

public class SecretaryController {
	private SecretaryService service;
	private /*add the object of the model*/ model;
}
