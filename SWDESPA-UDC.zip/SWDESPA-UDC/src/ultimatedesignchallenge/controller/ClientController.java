package ultimatedesignchallenge.controller;

public class ClientController {
	private ClientService service;
	private /*add the object of the model*/ model;
}
