package ultimatedesignchallenge.controller;

public class DoctorController {
	private DoctorService service;
	private /*add the object of the model*/ model;
}
