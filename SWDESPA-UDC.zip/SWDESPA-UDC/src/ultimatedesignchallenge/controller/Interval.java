package ultimatedesignchallenge.controller;

public interface Interval {
	public String startTime();
	public String endTime();
	public String doctor();
	public String client();
}
