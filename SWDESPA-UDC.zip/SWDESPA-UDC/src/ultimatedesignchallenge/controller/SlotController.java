package ultimatedesignchallenge.controller;

public class SlotController {
	private SlotService service;
	private /*add the object of the model*/ model;
}
