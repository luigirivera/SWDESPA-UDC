package ultimatedesignchallenge.controller;

public class RecurringController {
	private RecurringService service;
	private /*add the object of the model*/ model;
}
