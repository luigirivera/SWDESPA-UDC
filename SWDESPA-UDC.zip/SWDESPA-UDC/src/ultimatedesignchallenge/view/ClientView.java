package ultimatedesignchallenge.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import designchallenge1.CellStringFormatter;
import designchallenge1.EventStringFormatter;
import designchallenge1.HTMLCellMarkerFormatter;
import designchallenge1.HTMLEventMarkerFormatter;
import designchallenge2.item.CalendarEvent;
import designchallenge2.item.CalendarItem;
import designchallenge2.item.CalendarTask;
import designchallenge2.view.AgendaHTMLItemStringFormatter;
import designchallenge2.view.CalendarObserver;
import designchallenge2.view.DayHTMLItemStringFormatter;
import designchallenge2.view.ItemStringFormatter;
import ultimatedesignchallenge.controller.SlotBuilder;
import ultimatedesignchallenge.controller.SlotC;
import ultimatedesignchallenge.model.Appointment;
import ultimatedesignchallenge.model.Client;
import ultimatedesignchallenge.model.User;

public class ClientView extends CalendarFramework{
	private static final long serialVersionUID = 1L;
	private User model;
	
	public ClientView(User model){
		super("Client Calendar - " + model.getFirstname());
		
//		this.model = model;
//		this.controller = controller;
		this.model = model;
		
		constructorGen("Client");
		doctorListInst();
		initListeners();
		init();
	}
	
	private void init()
	{
		save.addActionListener(new saveCreateBtnListener());
	}
	
	class saveCreateBtnListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			SlotBuilder builder = new SlotBuilder();
			SlotC slot;
			
			if(doctorsCBList.getSelectedItem() == "doctor1")
				slot = builder.buildDoc1Appointment(startTime.getSelectedItem().toString(), endTime.getSelectedItem().toString(), model.getFirstname());
			else
				slot = builder.buildDoc2Appointment(startTime.getSelectedItem().toString(), endTime.getSelectedItem().toString(), model.getFirstname());
			// to do: add created slot to database, set appointment ID based on appointment name
			
			//if(recurringAppRB.isSelected())
				// to do: also set recurringID 
		}
	}
	
	private void saveCreation() {
		Appointment appointment = new Appointment();
		String[] startDate = new String[3];
		LocalDateTime startDateTime, endDateTime;
		
		try {
			if(createName.getText().equals(createPlaceholderName) || createName.getText().isEmpty())
				throw new Exception("Please enter a name");
			if(this.startDate.getText().equals(createPlaceholderStartDate) || this.startDate.getText().isEmpty())
				throw new Exception("Please enter a starting date");
			startDate = this.startDate.getText().split("/");
			if(startDate.length !=3)
				throw new Exception("Invalid date format");
			startDateTime = LocalDateTime.of(LocalDate.of(Integer.valueOf(startDate[0]), 
					Integer.valueOf(startDate[1]), Integer.valueOf(startDate[2])), (LocalTime) startTime.getSelectedItem());
			
			endDateTime = LocalDateTime.of(LocalDate.of(Integer.valueOf(startDate[0]), 
					Integer.valueOf(startDate[1]), Integer.valueOf(startDate[2])), (LocalTime) endTime.getSelectedItem());
			System.out.println(startDateTime);
			System.out.println(endDateTime);
			
			appointment.setClient((Client)model);
			appointment.s
			
			
			if(recurringAppRB.isSelected())
				//set recurring appointment    controller.addTask(createName.getText(), startDateTime, some stuff to add);
			
			else
				//set single appointment       controller.addEvent(createName.getText(), startDateTime, endDateTime);
		
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
		view.toggleCreateView(false);
		view.update();
	}
}